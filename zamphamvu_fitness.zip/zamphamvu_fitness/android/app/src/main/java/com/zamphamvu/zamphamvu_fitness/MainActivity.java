package com.zamphamvu.zamphamvu_fitness;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
