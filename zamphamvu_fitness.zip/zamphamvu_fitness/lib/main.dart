import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:zamphamvu_fitness/constants.dart';
import 'package:zamphamvu_fitness/screens/components/splash_screen.dart';
import 'package:get/get.dart';

void main(){
  HttpOverrides.global = new MyHttpOverrides();
  runApp(Zamphamvu());
}

class Zamphamvu extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: ' Zamphamvu ',
      theme: ThemeData(
        fontFamily: 'Poppings',
        primaryColor: Colors.white,
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          elevation: 0,
          foregroundColor: Colors.white,
        ),
        colorScheme: ColorScheme.fromSwatch()
            .copyWith(secondary: kPrimaryColor),
        textTheme: TextTheme(
            headline1: TextStyle(fontSize: 22.0, color: Colors.blueAccent),
            headline2: TextStyle(
              fontSize: 24.0,
              fontWeight: FontWeight.w700,
              color: Colors.blueAccent,
            ),
            bodyText1: TextStyle(
              fontSize: 14.0,
              fontWeight: FontWeight.w700,
              color: Colors.blueAccent,
            )
        ),
        scaffoldBackgroundColor: kBackgroundColor,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: SplashScreen(),
    );
  }
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}