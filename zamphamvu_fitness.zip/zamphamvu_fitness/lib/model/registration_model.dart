import 'package:flutter/foundation.dart';

class RegistrationModel extends ChangeNotifier {
  String? name;
  String? email;
  String? password;
  String? education;

  int activeIndex = 0;
  int totalIndex = 12;

  changeStep(int index) {
    activeIndex = index;
    notifyListeners();
  }
}
