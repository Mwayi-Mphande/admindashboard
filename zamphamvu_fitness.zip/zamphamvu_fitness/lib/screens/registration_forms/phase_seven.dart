import 'package:flutter/material.dart';
import 'package:cupertino_icons/cupertino_icons.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:im_stepper/stepper.dart';
import 'package:provider/provider.dart';

import '../../model/registration_model.dart';

class ClientInformationPhaseSeven extends StatefulWidget {
  const ClientInformationPhaseSeven({Key? key}) : super(key: key);

  @override
  State<ClientInformationPhaseSeven> createState() =>
      _ClientInformationPhaseSevenState();
}

class _ClientInformationPhaseSevenState extends State<ClientInformationPhaseSeven> {
  GlobalKey<FormState> clientInformationPhaseOneFormKey =
  GlobalKey<FormState>();

  bool weightLoss = false;
  bool muscleGain = false;
  bool improvedEndurance = false;
  bool increasedFlexibility = false;
  bool improvedImmuneSystem = false;
  bool improvedCardiovascularFitness = false;
  bool improvedStrength = false;
  bool other = false;


  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseOneFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotCount: 12,
                dotRadius: 20.0,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "What Motivates you to pursue fitness?",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),


            const Text(
              "What is your fitness Goal?",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: weightLoss,
                onChanged: (value){
                  setState((){
                    weightLoss = !weightLoss;
                  });
                },
              ),
              title: const Text("Weight loss"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: muscleGain,
                onChanged: (value){
                  setState((){
                    muscleGain = !muscleGain;
                  });
                },
              ),
              title: const Text("Muscle gain"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: improvedEndurance,
                onChanged: (value){
                  setState((){
                    improvedEndurance = !improvedEndurance;
                  });
                },
              ),
              title: const Text("Weight Lifting"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: increasedFlexibility,
                onChanged: (value){
                  setState((){
                    increasedFlexibility = !increasedFlexibility;
                  });
                },
              ),
              title: const Text("Increased flexibility"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: improvedImmuneSystem,
                onChanged: (value){
                  setState((){
                    improvedImmuneSystem = !improvedImmuneSystem;
                  });
                },
              ),
              title: Text("Improved immune system"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: improvedCardiovascularFitness,
                onChanged: (value){
                  setState((){
                    improvedCardiovascularFitness = !improvedCardiovascularFitness;
                  });
                },
              ),
              title: Text("Improved cadiovascular fitness"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: improvedStrength,
                onChanged: (value){
                  setState((){
                    improvedStrength = !improvedStrength;
                  });
                },
              ),
              title: Text("Improved strength"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: other,
                onChanged: (value){
                  setState((){
                    other = !other;
                  });
                },
              ),
              title: Text("Other"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            Visibility(
              visible: other,
              child: TextFormField(
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Please Specify",
                ),
                validator:  RequiredValidator(
                  errorText: "Required *",
                ),
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),










            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseOneFormKey.currentState
                      ?.validate() ??
                      false) {
                    modal.changeStep(8);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}