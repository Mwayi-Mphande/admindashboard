import 'package:flutter/material.dart';
import 'package:cupertino_icons/cupertino_icons.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:im_stepper/stepper.dart';
import 'package:provider/provider.dart';

import '../../model/registration_model.dart';

class MedicalQuestionPhaseOne extends StatefulWidget {
  const MedicalQuestionPhaseOne({Key? key}) : super(key: key);

  @override
  State<MedicalQuestionPhaseOne> createState() =>
      _MedicalQuestionPhaseOneState();
}

class _MedicalQuestionPhaseOneState extends State<MedicalQuestionPhaseOne> {
  GlobalKey<FormState> clientInformationPhaseOneFormKey =
  GlobalKey<FormState>();

  bool heartDisease = false;
  bool cardiovascularConditions = false;
  bool dizziness = false;
  bool blackoutsFainting = false;
  bool asthma = false;
  bool highOrLowBloodPressure = false;
  bool arthritis = false;
  bool diabetesEpilepsyOrFits = false;
  bool gout = false;
  bool familyHistoryOfHeartDisease = false;
  bool infectiousDiseases = false;
  bool other = false;


  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseOneFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotCount: 12,
                dotRadius: 20.0,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),

            const Text(
              "Have you ever or do you have any of the following?",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: heartDisease,
                onChanged: (value){
                  setState((){
                    heartDisease = !heartDisease;
                  });
                },
              ),
              title: const Text("Heart Disease"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: cardiovascularConditions,
                onChanged: (value){
                  setState((){
                    cardiovascularConditions = !cardiovascularConditions;
                  });
                },
              ),
              title: const Text("Cardio-vascular conditions"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: dizziness,
                onChanged: (value){
                  setState((){
                    dizziness = !dizziness;
                  });
                },
              ),
              title: const Text("Dizziness"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: blackoutsFainting,
                onChanged: (value){
                  setState((){
                    blackoutsFainting = !blackoutsFainting;
                  });
                },
              ),
              title: const Text("Blackouts Fainting"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: asthma,
                onChanged: (value){
                  setState((){
                    asthma = !asthma;
                  });
                },
              ),
              title: const Text("Asthma"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: highOrLowBloodPressure,
                onChanged: (value){
                  setState((){
                    highOrLowBloodPressure = !highOrLowBloodPressure;
                  });
                },
              ),
              title:const Text("High / Low blood pressure"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: arthritis,
                onChanged: (value){
                  setState((){
                    arthritis = !arthritis;
                  });
                },
              ),
              title: const Text("Arthritis"),
            ),
            const SizedBox(
              height: 12.0,
            ),

            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: diabetesEpilepsyOrFits,
                onChanged: (value){
                  setState((){
                    diabetesEpilepsyOrFits = !diabetesEpilepsyOrFits;
                  });
                },
              ),
              title: const Text("Diabetes Epilepsy / Fits"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: gout,
                onChanged: (value){
                  setState((){
                    gout = !gout;
                  });
                },
              ),
              title: const Text("Gout"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: familyHistoryOfHeartDisease,
                onChanged: (value){
                  setState((){
                    familyHistoryOfHeartDisease = !familyHistoryOfHeartDisease;
                  });
                },
              ),
              title: const Text("Family history of Heart disease"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: infectiousDiseases,
                onChanged: (value){
                  setState((){
                    infectiousDiseases = !infectiousDiseases;
                  });
                },
              ),
              title:const Text("High / Low blood pressure"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: other,
                onChanged: (value){
                  setState((){
                    other = !other;
                  });
                },
              ),
              title: const Text("Other"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            Visibility(
              visible: other,
              child: TextFormField(
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Please Specify",
                ),
                validator:  RequiredValidator(
                  errorText: "Required *",
                ),
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),









            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseOneFormKey.currentState
                      ?.validate() ??
                      false) {
                    modal.changeStep(10);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}