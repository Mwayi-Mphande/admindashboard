import 'package:flutter/material.dart';
import 'package:cupertino_icons/cupertino_icons.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:im_stepper/stepper.dart';
import 'package:provider/provider.dart';

import '../../model/registration_model.dart';

class MedicalQuestionPhaseTwo extends StatefulWidget {
  const MedicalQuestionPhaseTwo({Key? key}) : super(key: key);

  @override
  State<MedicalQuestionPhaseTwo> createState() =>
      _MedicalQuestionPhaseTwoState();
}

class _MedicalQuestionPhaseTwoState extends State<MedicalQuestionPhaseTwo> {
  GlobalKey<FormState> clientInformationPhaseOneFormKey =
  GlobalKey<FormState>();

  bool knees = false;
  bool lowerBack = false;
  bool neckOrShoulders = false;
  bool hipsOrPelvis = false;
  bool flexibility = false;
  bool other = false;


  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseOneFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotCount: 12,
                dotRadius: 20.0,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),

            const Text(
              "Do you have problems / injuries in the following areas?\n"
                  "(Please tick and explain to the best of your ability)",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: knees,
                onChanged: (value){
                  setState((){
                    knees = !knees;
                  });
                },
              ),
              title: const Text("Knees"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: lowerBack,
                onChanged: (value){
                  setState((){
                    lowerBack = !lowerBack;
                  });
                },
              ),
              title: const Text("Lower back"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: neckOrShoulders,
                onChanged: (value){
                  setState((){
                    neckOrShoulders = !neckOrShoulders;
                  });
                },
              ),
              title: const Text("Neck/Shoulders"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: hipsOrPelvis,
                onChanged: (value){
                  setState((){
                    hipsOrPelvis = !hipsOrPelvis;
                  });
                },
              ),
              title: const Text("Hips/Pelvis"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: flexibility,
                onChanged: (value){
                  setState((){
                    flexibility = !flexibility;
                  });
                },
              ),
              title: const Text("Flexibility"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: other,
                onChanged: (value){
                  setState((){
                    other = !other;
                  });
                },
              ),
              title: const Text("Other"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            Visibility(
              visible: other,
              child: TextFormField(
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Please Specify",
                ),
                validator:  RequiredValidator(
                  errorText: "Required *",
                ),
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),









            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseOneFormKey.currentState
                      ?.validate() ??
                      false) {
                    modal.changeStep(11);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}