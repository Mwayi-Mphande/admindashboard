import 'package:flutter/material.dart';
import 'package:cupertino_icons/cupertino_icons.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:im_stepper/stepper.dart';
import 'package:provider/provider.dart';

import '../../model/registration_model.dart';

class ClientInformationPhaseEight extends StatefulWidget {
  const ClientInformationPhaseEight({Key? key}) : super(key: key);

  @override
  State<ClientInformationPhaseEight> createState() =>
      _ClientInformationPhaseEightState();
}

class _ClientInformationPhaseEightState extends State<ClientInformationPhaseEight> {
  GlobalKey<FormState> clientInformationPhaseOneFormKey =
  GlobalKey<FormState>();

  bool shoulders = false;
  bool chest = false;
  bool back = false;
  bool legs = false;
  bool arms = false;
  bool abs = false;
  bool wholeBody = false;

  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseOneFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotCount: 12,
                dotRadius: 20.0,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),

            const Text(
              "If the goal is muscle gain, which body area(s) do you want to "
                  "gain muscles on? Tick below",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: shoulders,
                onChanged: (value){
                  setState((){
                    shoulders = !shoulders;
                  });
                },
              ),
              title: const Text("Shoulders"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: chest,
                onChanged: (value){
                  setState((){
                    chest = !chest;
                  });
                },
              ),
              title: const Text("Chest"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: back,
                onChanged: (value){
                  setState((){
                    back = !back;
                  });
                },
              ),
              title: const Text("Back"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: legs,
                onChanged: (value){
                  setState((){
                    legs = !legs;
                  });
                },
              ),
              title: const Text("Legs"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: arms,
                onChanged: (value){
                  setState((){
                    arms = !arms;
                  });
                },
              ),
              title: Text("Arms"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: abs,
                onChanged: (value){
                  setState((){
                    abs = !abs;
                  });
                },
              ),
              title:const Text("Abs( Six-pack )"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: wholeBody,
                onChanged: (value){
                  setState((){
                    wholeBody = !wholeBody;
                  });
                },
              ),
              title: const Text("Whole body"),
            ),
            const SizedBox(
              height: 12.0,
            ),










            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseOneFormKey.currentState
                      ?.validate() ??
                      false) {
                    modal.changeStep(9);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}