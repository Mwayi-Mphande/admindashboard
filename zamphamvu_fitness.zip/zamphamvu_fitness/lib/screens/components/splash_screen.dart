import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zamphamvu_fitness/screens/registration_form.dart';


String? userEmail;
class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState(){
    super.initState();
    getValidationData().whenComplete(() async{
      Timer(const Duration(seconds: 10), ()=>Get.off(()=>RegistrationForm()));
    });

  }
  Future getValidationData() async {
    final SharedPreferences sharedPreferences =
    await SharedPreferences.getInstance();
    var retrievedEmail = sharedPreferences.getString('email');

    setState(() {
      userEmail = retrievedEmail;
    });
  }



  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: Colors.blueAccent,
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    "assets/icons/zamphamvu_fitness_logo.PNG",
                  ),
                  Padding(padding: EdgeInsets.only(top: 10.0),
                  ),
                  Text(
                      "ZAMPHANVU",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 40.0
                    ),
                  ),
                  Text(
                      "Work, Sweat and Achieve",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15.0
                    ),
                  ),
                  Text(
                      "...",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20.0
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
