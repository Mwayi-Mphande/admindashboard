import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:im_stepper/stepper.dart';
import 'package:provider/provider.dart';
import 'package:zamphamvu_fitness/model/registration_model.dart';
import 'package:zamphamvu_fitness/screens/date_time_picker.dart';
import 'package:zamphamvu_fitness/screens/home_screen.dart';
import 'package:zamphamvu_fitness/screens/registration_forms/medicalQuestionPhaseTwo.dart';
import 'package:zamphamvu_fitness/screens/registration_forms/medical_question_phase_one.dart';
import 'package:zamphamvu_fitness/screens/registration_forms/phase_eight.dart';
import 'package:zamphamvu_fitness/screens/registration_forms/phase_seven.dart';

class RegistrationForm extends StatefulWidget {
  const RegistrationForm({Key? key}) : super(key: key);

  @override
  State<RegistrationForm> createState() => _RegistrationFormState();
}

class _RegistrationFormState extends State<RegistrationForm> {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<RegistrationModel>(
      create: (context) => RegistrationModel(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            " Registration Form",
          ),
        ),
        body: Consumer<RegistrationModel>(
          builder: (context, modal, child) {
            switch (modal.activeIndex) {
              case 0:
                return const RegistrationAuthentication();
              case 1:
                return const ClientInformationPhaseOne();
              case 2:
                return const ClientInformationPhaseTwo();

              case 3:
                return const ClientInformationPhaseThree();

              case 4:
                return const ClientInformationPhaseFour();

              case 5:
                return const ClientInformationPhaseFive();

              case 6:
                return const ClientInformationPhaseSix();

              case 7:
                return const ClientInformationPhaseSeven();

              case 8:
                return const ClientInformationPhaseEight();

              case 9:
                return const MedicalQuestionPhaseOne();

              case 10:
                return const MedicalQuestionPhaseTwo();

              case 11:
                return const HomeScreen();

              default:
                return const RegistrationAuthentication();
            }
          },
        ),
      ),
    );
  }
}

class RegistrationAuthentication extends StatefulWidget {
  const RegistrationAuthentication({Key? key}) : super(key: key);

  @override
  _RegistrationAuthenticationState createState() =>
      _RegistrationAuthenticationState();
}

class _RegistrationAuthenticationState
    extends State<RegistrationAuthentication> {
  GlobalKey<FormState> basicFormKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: basicFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotCount: 12,
                dotRadius: 20.0,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Enter your Access Code",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Email",
                ),
                validator: MultiValidator([
                  RequiredValidator(
                    errorText: "Required *",
                  ),
                  EmailValidator(
                    errorText: "Not Valid Email",
                  ),
                ])),
            const SizedBox(
              height: 12.0,
            ),
            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (basicFormKey.currentState?.validate() ?? false) {
                    // next
                    modal.changeStep(1);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}

class ClientInformationPhaseOne extends StatefulWidget {
  const ClientInformationPhaseOne({Key? key}) : super(key: key);

  @override
  State<ClientInformationPhaseOne> createState() =>
      _ClientInformationPhaseOneState();
}

class _ClientInformationPhaseOneState extends State<ClientInformationPhaseOne> {
  GlobalKey<FormState> clientInformationPhaseOneFormKey =
      GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseOneFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotCount: 12,
                dotRadius: 20.0,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "How did you find out about Zamphanvu Fitness",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Where do you stay?",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "How many times do you eat in a day?",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "What is your favourite food?",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText:
                    "Roughly, how many glasses of water do you take in a day?",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseOneFormKey.currentState
                          ?.validate() ??
                      false) {
                    modal.changeStep(2);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}

class ClientInformationPhaseTwo extends StatefulWidget {
  const ClientInformationPhaseTwo({Key? key}) : super(key: key);

  @override
  State<ClientInformationPhaseTwo> createState() =>
      _ClientInformationPhaseTwoState();
}

class _ClientInformationPhaseTwoState extends State<ClientInformationPhaseTwo> {
  GlobalKey<FormState> clientInformationPhaseTwoFormKey =
      GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseTwoFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotRadius: 20.0,
                dotCount: 12,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),
            const Text(
              "How many times in a week do you eat the fruits below",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Water Melon",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Strawberries",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Oranges",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Plums",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Peaches",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Papaya",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Apples",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Mangoes",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseTwoFormKey.currentState
                          ?.validate() ??
                      false) {
                    modal.changeStep(3);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}

class ClientInformationPhaseThree extends StatefulWidget {
  const ClientInformationPhaseThree({Key? key}) : super(key: key);

  @override
  State<ClientInformationPhaseThree> createState() =>
      _ClientInformationPhaseThreeState();
}

class _ClientInformationPhaseThreeState
    extends State<ClientInformationPhaseThree> {
  GlobalKey<FormState> clientInformationPhaseThreeFormKey =
      GlobalKey<FormState>();
  String vegetarian = "No";

  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseThreeFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotRadius: 20.0,
                dotCount: 12,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),
            const Text(
              "Are you a vegetarian?",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            RadioListTile(
              title: Text("Yes"),
              value: "Yes",
              groupValue: vegetarian,
              onChanged: (value) {
                setState(() {
                  vegetarian = value.toString();
                });
              },
            ),
            RadioListTile(
              title: Text("No"),
              value: "No",
              groupValue: vegetarian,
              onChanged: (value) {
                setState(() {
                  vegetarian = value.toString();
                });
              },
            ),
            const SizedBox(
              height: 12.0,
            ),

            const SizedBox(
              height: 12.0,
            ),
            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseThreeFormKey.currentState
                      ?.validate() ??
                      false) {
                    modal.changeStep(4);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}

class ClientInformationPhaseFour extends StatefulWidget {
  const ClientInformationPhaseFour({Key? key}) : super(key: key);

  @override
  State<ClientInformationPhaseFour> createState() =>
      _ClientInformationPhaseFourState();
}

class _ClientInformationPhaseFourState
    extends State<ClientInformationPhaseFour> {
  GlobalKey<FormState> clientInformationPhaseFourFormKey =
      GlobalKey<FormState>();
  bool monday = false;
  bool tuesday = false;
  bool wednesday = false;
  bool thursday = false;
  bool friday = false;
  bool saturday = false;
  bool sunday = false;


  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseFourFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotRadius: 20.0,
                dotCount: 12,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),
            const Text(
              "Which day(s) of the week are free?",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: monday,
                onChanged: (value){
                  setState((){
                    this.monday = !monday;
                  });
                },
              ),
              title: Text("Monday"),
            ),
            Visibility(
              visible: monday,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  new Expanded(
                    flex: 4,
                    child: new TimePicker(),
                  ),
                  const SizedBox(width: 12.0),
                  Text('to \t'),
                  new Expanded(
                    flex: 3,
                    child: new TimePicker(),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: tuesday,
                onChanged: (value){
                  setState((){
                    this.tuesday = !tuesday;
                  });
                },
              ),
              title: Text("Tuesday"),
            ),
            Visibility(
              visible: tuesday,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  new Expanded(
                    flex: 4,
                    child: new TimePicker(),
                  ),
                  const SizedBox(width: 12.0),
                  Text('to \t'),
                  new Expanded(
                    flex: 3,
                    child: new TimePicker(),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: wednesday,
                onChanged: (value){
                  setState((){
                    this.wednesday = !wednesday;
                  });
                },
              ),
              title: Text("Wednesday"),
            ),
            Visibility(
              visible: wednesday,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  new Expanded(
                    flex: 4,
                    child: new TimePicker(),
                  ),
                  const SizedBox(width: 12.0),
                  Text('to \t'),
                  new Expanded(
                    flex: 3,
                    child: new TimePicker(),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: thursday,
                onChanged: (value){
                  setState((){
                    this.thursday = !thursday;
                  });
                },
              ),
              title: Text("Thursday"),
            ),
            Visibility(
              visible: thursday,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  new Expanded(
                    flex: 4,
                    child: new TimePicker(),
                  ),
                  const SizedBox(width: 12.0),
                  Text('to \t'),
                  new Expanded(
                    flex: 3,
                    child: new TimePicker(),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: friday,
                onChanged: (value){
                  setState((){
                    this.friday = !friday;
                  });
                },
              ),
              title: Text("Friday"),
            ),
            Visibility(
              visible: friday,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  new Expanded(
                    flex: 4,
                    child: new TimePicker(),
                  ),
                  const SizedBox(width: 12.0),
                  Text('to \t'),
                  new Expanded(
                    flex: 3,
                    child: new TimePicker(),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: saturday,
                onChanged: (value){
                  setState((){
                    this.saturday = !saturday;
                  });
                },
              ),
              title: Text("Saturday"),
            ),
            Visibility(
              visible: saturday,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  new Expanded(
                    flex: 4,
                    child: new TimePicker(),
                  ),
                  const SizedBox(width: 12.0),
                  Text('to \t'),
                  new Expanded(
                    flex: 3,
                    child: new TimePicker(),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: sunday,
                onChanged: (value){
                  setState((){
                    this.sunday = !sunday;
                  });
                },
              ),
              title: Text("Sunday"),
            ),
            Visibility(
              visible: sunday,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  new Expanded(
                    flex: 4,
                    child: new TimePicker(),
                  ),
                  const SizedBox(width: 12.0),
                  Text('to \t'),
                  new Expanded(
                    flex: 3,
                    child: new TimePicker(),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseFourFormKey.currentState
                      ?.validate() ??
                      false) {
                    modal.changeStep(5);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),

          ],
        ),
      );
    });
  }
}

class ClientInformationPhaseFive extends StatefulWidget {
  const ClientInformationPhaseFive({Key? key}) : super(key: key);

  @override
  State<ClientInformationPhaseFive> createState() =>
      _ClientInformationPhaseFiveState();
}

class _ClientInformationPhaseFiveState extends State<ClientInformationPhaseFive> {
  GlobalKey<FormState> clientInformationPhaseOneFormKey =
  GlobalKey<FormState>();

  String alcoholConsuption = 'No';
  bool alcoholFieldVisibility = false;

  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseOneFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotCount: 12,
                dotRadius: 20.0,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "What is your body weight",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Wha is your body height?",
              ),
              validator: RequiredValidator(
                errorText: "Required *",
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            Text("BMI"),

            const SizedBox(
              height: 12.0,
            ),
            const Text(
              "Do you drink Alcohol?",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            RadioListTile(
              title: Text("Yes"),
              value: "Yes",
              groupValue: alcoholConsuption,
              onChanged: (value) {
                setState(() {
                  alcoholConsuption = value.toString();
                  alcoholFieldVisibility = true;
                });
              },
            ),
            RadioListTile(
              title: Text("No"),
              value: "No",
              groupValue: alcoholConsuption,
              onChanged: (value) {
                setState(() {
                  alcoholConsuption = value.toString();
                  alcoholFieldVisibility = false;
                });
              },
            ),
            const SizedBox(
              height: 12.0,
            ),
            Visibility(
              visible: alcoholFieldVisibility,
              child: TextFormField(
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "How often in a week or a month?",
                ),
                validator:  RequiredValidator(
                  errorText: "Required *",
                ),
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            SizedBox(
              height: 40.0,

              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseOneFormKey.currentState
                      ?.validate() ??
                      false) {
                    modal.changeStep(6);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}

class ClientInformationPhaseSix extends StatefulWidget {
  const ClientInformationPhaseSix({Key? key}) : super(key: key);

  @override
  State<ClientInformationPhaseSix> createState() =>
      _ClientInformationPhaseSixState();
}

class _ClientInformationPhaseSixState
    extends State<ClientInformationPhaseSix> {
  GlobalKey<FormState> clientInformationPhaseFourFormKey =
  GlobalKey<FormState>();
  bool boxing = false;
  bool jogging = false;
  bool weight_lifting = false;
  bool football = false;
  bool netball = false;
  bool cycling = false;
  bool other = false;


  @override
  Widget build(BuildContext context) {
    return Consumer<RegistrationModel>(builder: (context, modal, child) {
      return Form(
        key: clientInformationPhaseFourFormKey,
        child: ListView(
          padding: const EdgeInsets.all(
            12.0,
          ),
          children: [
            Center(
              child: DotStepper(
                activeStep: modal.activeIndex,
                dotRadius: 20.0,
                dotCount: 12,
                shape: Shape.pipe,
                spacing: 10.0,
              ),
            ),
            Text(
              "Step ${modal.activeIndex + 1} of ${modal.totalIndex}",
              style: const TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 12.0,
            ),
            const Text(
              "Do you have any athletic experience?(If Yes Tick below)",
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.left,
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: boxing,
                onChanged: (value){
                  setState((){
                    this.boxing = !boxing;
                  });
                },
              ),
              title: Text("Boxing"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: jogging,
                onChanged: (value){
                  setState((){
                    this.jogging = !jogging;
                  });
                },
              ),
              title: Text("Jogging"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: weight_lifting,
                onChanged: (value){
                  setState((){
                    this.weight_lifting = !weight_lifting;
                  });
                },
              ),
              title: Text("Weight Lifting"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: football,
                onChanged: (value){
                  setState((){
                    this.football = !football;
                  });
                },
              ),
              title: Text("Football"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: netball,
                onChanged: (value){
                  setState((){
                    this.netball = !netball;
                  });
                },
              ),
              title: Text("Netball"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: cycling,
                onChanged: (value){
                  setState((){
                    this.cycling = !cycling;
                  });
                },
              ),
              title: Text("Cycling"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            ListTile(
              leading: Checkbox(
                value: other,
                onChanged: (value){
                  setState((){
                    this.other = !other;
                  });
                },
              ),
              title: Text("Other"),
            ),
            const SizedBox(
              height: 12.0,
            ),
            Visibility(
              visible: other,
              child: TextFormField(
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Please Specify your athletic experience",
                ),
                validator:  RequiredValidator(
                  errorText: "Required *",
                ),
              ),
            ),
            const SizedBox(
              height: 12.0,
            ),
            SizedBox(
              height: 40.0,
              child: ElevatedButton(
                onPressed: () {
                  if (clientInformationPhaseFourFormKey.currentState
                      ?.validate() ??
                      false) {
                    modal.changeStep(7);
                  }
                },
                child: const Text(
                  "Next",
                  style: TextStyle(
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),

          ],
        ),
      );
    });
  }
}

